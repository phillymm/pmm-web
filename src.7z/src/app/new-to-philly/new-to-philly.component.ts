import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-to-philly',
  templateUrl: './new-to-philly.component.html'
})
export class NewToPhillyComponent implements OnInit {
  yourName = '';
  constructor() { }

  ngOnInit() {
  }

}
